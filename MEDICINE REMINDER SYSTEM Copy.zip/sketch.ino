#include <Wire.h>
#include <RTClib.h>
#include <LiquidCrystal.h>

RTC_DS1307 rtc;
LiquidCrystal lcd(12,11,5,4,3,2);

int led = 13;
int buzzer = 8;

void setup() {

  lcd.begin(16,2);
  Wire.begin();
  rtc.begin();

  pinMode(led, OUTPUT);
  pinMode(buzzer, OUTPUT);

  lcd.print("Medicine System");
  delay(2000);
}

void loop() {

  DateTime now = rtc.now();

  int hour = now.hour();
  int minute = now.minute();

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Time: ");
  lcd.print(hour);
  lcd.print(":");
  lcd.print(minute);

  // Morning medicine
  if(hour == 8 && minute == 0){
    reminder("Morning Dose");
  }

  // Afternoon medicine
  if(hour == 13 && minute == 20){
    reminder("Afternoon Dose");
  }

  // Night medicine
  if(hour == 21 && minute == 0){
    reminder("Night Dose");
  }

  delay(1000);
}

void reminder(String message){

  lcd.setCursor(0,1);
  lcd.print(message);

  digitalWrite(led, HIGH);
  tone(buzzer,1000);

  delay(5000);

  digitalWrite(led, LOW);
  noTone(buzzer);
}